<?php /* Smarty version 2.6.14, created on 2013-11-09 02:09:48
         compiled from Footer.tpl */ ?>

<div id="footer">
	<div class='ad_bottom' style='display: block; visibility: visible;padding:5px;'>
	  <?php echo $this->_tpl_vars['ads']->ad_bottom; ?>

	</div>
			<!--div class="f-right">
				<a href="#">English</a>
			</div -->
            <p>&copy;2013 PicBook. All rights reserved</p>
        </div>
	</div>
	
</div>
</body>
</html>

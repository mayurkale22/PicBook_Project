<?php /* Smarty version 2.6.14, created on 2013-11-17 13:49:41
         compiled from footer.tpl */ ?>

<div id="footer">
	<div class='ad_bottom' style='display: block; visibility: visible;padding:5px;'>
	</div>
			<!--div class="f-right">
				<a href="#">English</a>
			</div -->
            <p><a href="#">PHPSocial</a> &copy; 2009-2010</p>
        </div>
	
</div>



</body>
</html>
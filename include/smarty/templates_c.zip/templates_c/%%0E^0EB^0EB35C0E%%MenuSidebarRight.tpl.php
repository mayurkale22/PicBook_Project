<?php /* Smarty version 2.6.14, created on 2013-11-09 02:09:48
         compiled from MenuSidebarRight.tpl */ ?>

<?php if ($this->_tpl_vars['ads']->ad_right != ""): ?>
<div class="block">
	<div class='ad_right' style=' visibility: visible;text-align: center;'><?php echo $this->_tpl_vars['ads']->ad_right; ?>
</div>
</div>
<?php endif; ?>
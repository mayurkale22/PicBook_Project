<?php /* Smarty version 2.6.14, created on 2013-11-09 01:55:40
         compiled from AdminFooter.tpl */ ?>
</div>

</div>
<div class="block-bot"><span></span></div>
</div>
</div>
<div id="footer">

    <p><a href="http://phpsocial.com/">PhpSocial</a> &copy; 2006-2009</p>
</div>
</div>
</body>
</html>